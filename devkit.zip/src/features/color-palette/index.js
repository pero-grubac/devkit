export { ColorPalette } from './ColorPalette';
