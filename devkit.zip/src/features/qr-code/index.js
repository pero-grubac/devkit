export { QrTool } from './QrTool';
